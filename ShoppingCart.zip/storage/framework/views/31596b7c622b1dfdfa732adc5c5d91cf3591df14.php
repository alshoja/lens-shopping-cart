<?php $__env->startSection('content'); ?>
<?php echo $__env->make('users.partials.header', ['title' => __('Delivery')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container-fluid mt--7">
    <div class="row">
        <div class="col-xl-12 order-xl-1">
            <div class="card bg-secondary shadow">
                <div class="card-header bg-white border-0">
                    <div class="row align-items-center">
                        <div class="col-8">
                            <h3 class="mb-0"><?php echo e(__('Delivery Places')); ?></h3>
                        </div>
                        <div class="col-4 text-right">
                            <a href="<?php echo e(route('user.index')); ?>"
                                class="btn btn-sm btn-primary"><?php echo e(__('Back to list')); ?></a>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <form method="post" action="<?php echo e(route('user.store')); ?>" autocomplete="off">
                        <?php echo csrf_field(); ?>

                        <h6 class="heading-small text-muted mb-4"><?php echo e(__('Add Delivery Place')); ?></h6>
                        <div class="pl-lg-4">

                            <div class="row">
                                    <div class="col-sm">
                                            <div class="form-group<?php echo e($errors->has('state') ? ' has-danger' : ''); ?>">
                                                <label class="form-control-label" for="input-email"><?php echo e(__('State')); ?></label>
                                                <div class="input-group mb-3">
                                                        <select class="form-control" id="exampleFormControlSelect1">
                                                          <option>1</option>
                                                          <option>2</option>
                                                          <option>3</option>
                                                          <option>4</option>
                                                          <option>5</option>
                                                        </select>

                                                      </div>
                                                <?php if($errors->has('state')): ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($errors->first('state')); ?></strong>
                                                </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>

                                        <div class="col-sm">
                                            <div class="form-group<?php echo e($errors->has('state') ? ' has-danger' : ''); ?>">
                                                <label class="form-control-label" for="input-email"><?php echo e(__('DIstrict')); ?></label>
                                                <div class="input-group mb-3">
                                                        <select class="form-control" id="exampleFormControlSelect1">
                                                          <option>1</option>
                                                          <option>2</option>
                                                          <option>3</option>
                                                          <option>4</option>
                                                          <option>5</option>
                                                        </select>

                                                      </div>
                                                <?php if($errors->has('state')): ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($errors->first('state')); ?></strong>
                                                </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                <div class="col-sm">
                                        <div class="form-group<?php echo e($errors->has('Pincode') ? ' has-danger' : ''); ?>">
                                                <label class="form-control-label" for="input-email"><?php echo e(__('Pincode')); ?></label>
                                                <div class="input-group mb-3">
                                                        <div class="input-group-prepend">
                                                          <span class="input-group-text" id="basic-addon1"><i class="fas fa-city"></i></span>
                                                        </div>
                                                        <input type="text" class="form-control" name="pincode"  placeholder="<?php echo e(__(' Pincode')); ?>" aria-label="T url" aria-describedby="basic-addon1">
                                                      </div>
                                                <?php if($errors->has('pincode')): ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($errors->first('pincode')); ?></strong>
                                                </span>
                                                <?php endif; ?>
                                            </div>
                                </div>


                            </div>



                                  <div>

                                </div>
                            <div class="text-center">
                                <button type="submit" class="btn btn-success mt-4"><?php echo e(__('Save')); ?></button>
                            </div>

                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    
    <br>
    <div class="table-responsive">
            <div>
                <table class="table align-items-center">
                    <thead class="thead-light">
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">
                                Address
                            </th>
                            <th scope="col">
                             Pincode
                            </th>


                            <th scope="col"></th>
                        </tr>
                    </thead>
                    <tbody class="list">

                        <tr>
                            <th>1</th>
                            <th scope="row" class="name">
                                <div class="media align-items-center">
                                    <a href="#" class="avatar rounded-circle mr-3">
                                        <img alt="Image placeholder" src="../../assets/img/theme/bootstrap.jpg">
                                    </a>
                                    <div class="media-body">
                                        <span class="mb-0 text-sm">Argon Design System</span>
                                    </div>
                                </div>
                            </th>

                            <td class="status">
                                <span class="badge badge-dot mr-4">
                                    <i class="bg-warning"></i> Postion
                                </span>
                            </td>


                            <td class="text-right">
                                <div class="dropdown">
                                    <a class="btn btn-sm btn-icon-only text-light" href="#" role="button"
                                        data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        <i class="fas fa-ellipsis-v"></i>
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                        <a class="dropdown-item" href="#">Action</a>
                                        <a class="dropdown-item" href="#">Another action</a>
                                        <a class="dropdown-item" href="#">Something else here</a>
                                    </div>
                                </div>
                            </td>
                        </tr>


                    </tbody>
                </table>
            </div>

        </div>

    <?php echo $__env->make('layouts.footers.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['title' => __('Delivery')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alshoja/ShoppingCart/resources/views/stock-settings/delivery/delivery.blade.php ENDPATH**/ ?>