
            <?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>     
       
            <?php $__env->startSection('sidebar'); ?>
       
    
      

        <div class="container">
            <?php echo $__env->yieldContent('content'); ?>
        </div>

        <?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  
<?php /**PATH /home/alshoja/ShoppingCart/resources/views/layouts/master.blade.php ENDPATH**/ ?>