<?php

namespace App\Http\Controllers;

use App\Models\Contact;
use Illuminate\Http\Request;

class ContactController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $contact = Contact::First();
        return view('web-settings.Contact.contact', compact('contact'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Contact  $contact
     * @return \Illuminate\Http\Response
     */
    public function show(Contact $contact)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Contact  $contact
     * @return \Illuminate\Http\Response
     */
    public function edit(Contact $contact)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Contact  $contact
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Contact $contact)
    {
        $contact = Contact::first();
        if (request()->file('header_image')) {
            $file = request()->file('header_image')->store('uploads');
        } else {
            $file = $contact->header_image;
        }
        $contact->phone = $request->phone;
        $contact->country_code = $request->country_code;
        $contact->location = $request->location;
        $contact->email = $request->email;
        $contact->footer_subscribing_data = $request->footer_subscribing_data;
        $contact->rights_data = $request->rights_data;
        $contact->rights_company_name = $request->rights_company_name;
        $contact->company_url = $request->company_url;
        $contact->header_image = $file;
        $contact->title = $request->title;
        $contact->map_iframe_data = $request->map_iframe_data;
        $contact->save();
        return back();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Contact  $contact
     * @return \Illuminate\Http\Response
     */
    public function destroy(Contact $contact)
    {
        //
    }
}
