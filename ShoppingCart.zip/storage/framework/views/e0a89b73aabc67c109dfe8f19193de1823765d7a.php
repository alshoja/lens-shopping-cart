<?php $__env->startSection('title', $collection->name); ?>

<?php $__env->startSection('sidebar'); ?>
##parent-placeholder-19bd1503d9bad449304cc6b4e977b74bac6cc771##


<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">
<link href=<?php echo e(URL::asset("assets/css/rating.css")); ?> rel='stylesheet' type='text/css' />

<!-- banner -->
<div class="banner_inner" style=" background: url(<?php echo e(URL::asset("assets/images/banner-mid.jpg")); ?>)no-repeat 0px -55px;">
    <div class="services-breadcrumb">
        <div class="inner_breadcrumb">

            <ul class="short">
                <li>
                    <a href="<?php echo e(URL::to('/')); ?>">Home</a>
                    <i>|</i>
                </li>
                <li><?php echo e($collection->name); ?></li>
            </ul>
        </div>
    </div>

</div>

</div>
<!--//banner -->
<!--/shop-->
<section class="banner-bottom-wthreelayouts py-lg-5 py-3">
    <div class="container">
        <div class="inner-sec-shop pt-lg-4 pt-3">
            <div class="row">
                <div class="col-lg-4 single-right-left ">
                    <div class="grid images_3_of_2">
                        <div class="flexslider1">

                            <ul class="slides">
                                <?php $__currentLoopData = $collection->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li data-thumb="<?php echo e(URL::asset("assets/$img->image")); ?>">
                                    <div class="thumb-image"> <img src="<?php echo e(URL::asset("assets/$img->image")); ?>"
                                            data-imagezoom="true" class="img-fluid" alt=" "> </div>
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                            <div class="clearfix"></div>
                        </div>
                    </div>
                </div>



                <div class="col-lg-8 single-right-left simpleCart_shelfItem">
                    <h3> </h3>
                    <p><span class="item_price">₹ <?php echo e($collection->amount); ?></span>
                        <del>₹ <?php echo e($collection->old_price); ?></del>
                    </p>
                    <div class="rating1">
                        <ul class="stars">

                        <?php for($i = 0; $i < $collection->star; $i++): ?>
                                <li><a href="#"><i class="fa fa-star" style="color: orangered" aria-hidden="true"></i></a></li>
                        <?php endfor; ?>

                        <?php for($i = 0; $i < 5-$collection->star; $i++): ?>
                            <li><a href="#"><i class="fa fa-star"  aria-hidden="true"></i></a></li>
                        <?php endfor; ?>


                        </ul>
                    </div>
                    <div class="description">
                        <h5>Check delivery, payment options and charges at your location</h5>
                        <form action="#" method="post">
                            <input class="form-control" type="text" autocomplete="off"  id="search" name="search" placeholder="Check with your Pin Code"
                                required="">

                            <input type="submit" disabled value="search" >
                        </form>

                        <spans></spans>

                    </div>
                    <div class="color-quality">
                        <div class="color-quality-right">
                            <h5>Stock :<?php echo e($collection->stock); ?></h5>
                            
                        </div>
                    </div>
                    <div class="occasional">
                        <h5>Types :</h5>
                        <div class="colr ert">
                            <?php if(count($collection->types)==0): ?>
                            <h6>Sorry,No types Available for this item !</h6>
                            <?php else: ?>
                            <?php $__currentLoopData = $collection->types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Itemtype): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <label class="radio"><input type="radio" name="radio"><i></i> <?php echo e($Itemtype->type); ?></label>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>


                        </div>

                        <div class="clearfix"> </div>
                    </div>
                    <div class="occasion-cart">
                        <div class="googles single-item singlepage">
                            <form action="#" method="post">
                                <input type="hidden" name="cmd" value="_cart">
                                <input type="hidden" name="add" value="1">
                                <input type="hidden" name="googles_item" value="<?php echo e($collection->name); ?>">
                                <input type="hidden" name="amount" value="<?php echo e($collection->amount); ?>">
                                <input type="hidden" name="item_id" value=" <?php echo e($collection->id); ?>">
                                <button type="submit" class="googles-cart pgoogles-cart">
                                    Add to Cart
                                </button>

                            </form>

                        </div>
                    </div>
                    <ul class="footer-social text-left mt-lg-4 mt-3">
                        <li>Share On : </li>
                        <li class="mx-2">
                            <a href="#">
                                <span class="fab fa-facebook-f"></span>
                            </a>
                        </li>
                        <li class="mx-2">
                            <a href="#">
                                <span class="fab fa-twitter"></span>
                            </a>
                        </li>
                        <li class="mx-2">
                            <a href="#">
                                <span class="fab fa-google-plus-g"></span>
                            </a>
                        </li>
                        <li class="mx-2">
                            <a href="#">
                                <span class="fab fa-linkedin-in"></span>
                            </a>
                        </li>
                        <li class="mx-2">
                            <a href="#">
                                <span class="fas fa-rss"></span>
                            </a>
                        </li>

                    </ul>

                </div>






                <div class="clearfix"> </div>
                <!--/tabs-->
                <div class="responsive_tabs">
                    <div id="horizontalTab">
                        <ul class="resp-tabs-list">
                            <li>Description</li>
                            <li>Reviews</li>
                            
                        </ul>
                        <div class="resp-tabs-container">
                            <!--/tab_one-->
                            <div class="tab1">

                                <div class="single_page">
                                    <h6><?php echo e($collection->name); ?></h6>
                                    <p><?php echo e($collection->description); ?></p>

                                </div>
                            </div>
                            <!--//tab_one-->
                            <div class="tab2">

                                <div class="single_page">
                             
                                    <div class="bootstrap-tab-text-grids">
                                       
                                        <div class="add-review">
                                                <h4>add a review</h4>
<div class="row">
    <div class="col-md-6">
            <form action="<?php echo e(url('store/reviews')); ?>" method="post">
                <?php echo csrf_field(); ?>
                                                <fieldset class="rating">
                                                        <input type="radio" id="star5" name="rating" value="5" required /><label class = "full" for="star5" title="Awesome - 5 stars"></label>
                                                        
                                                        <input type="radio" id="star4" name="rating" value="4" /><label class = "full" for="star4" title="Pretty good - 4 stars"></label>
                                                        
                                                        <input type="radio" id="star3" name="rating" value="3" /><label class = "full" for="star3" title="Meh - 3 stars"></label>
                                                        
                                                        <input type="radio" id="star2" name="rating" value="2" /><label class = "full" for="star2" title="Kinda bad - 2 stars"></label>
                                                        
                                                        <input type="radio" id="star1" name="rating" value="1" /><label class = "full" for="star1" title="Sucks big time - 1 star"></label>
                                                        
                                                    </fieldset>
    </div>
    <div class="col-md-6">


                                                <input class="form-control" type="text" name="name"
                                                    placeholder="Name" required="">
                                                <input class="form-control" type="email" name="Email"
                                                    placeholder="Enter your email..." required="">
                                                    <input class="form-control" name="product_id" value="<?php echo e($collection->id); ?>" type="hidden" >
                                                <textarea name="message" required=""></textarea>
                                                <input type="submit" value="SEND">
                                            </form>
    </div>
                                        </div>
                                    </div>
                                    </div>
                                    <div class="bootstrap-tab-text-grid">
                                        <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Ritem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="bootstrap-tab-text-grid-left">
                                            <img width="20%" src="<?php echo e(URL::asset("assets/images/user.png")); ?>" alt=" "
                                                class="img-fluid">
                                        </div>

                                        <div class="bootstrap-tab-text-grid-right">
                                            <ul>
                                                <li><a href="#"><?php echo e($Ritem->users->name); ?></a></li>
                                                <li><a href="#"><i class="fa fa-reply-all" aria-hidden="true"></i>
                                                        Reply</a></li>
                                            </ul>
                                            <p><?php echo e($Ritem->review); ?></p>
                                        </div>

                                        <div class="clearfix"> </div>
                                        <hr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                   
                                    <?php echo e($reviews->links()); ?>

                                </div>
                            </div>
                             
                        </div>
                    </div>
                </div>
                <!--//tabs-->

            </div>
        </div>
    </div>
    <div class="container-fluid">
        <!--/slide-->
        <div class="slider-img mid-sec mt-lg-5 mt-2 px-lg-5 px-3">
            <!--//banner-sec-->
            <h3 class="tittle-w3layouts text-left my-lg-4 my-3">Featured Products</h3>
            <div class="mid-slider">

                <div class="owl-carousel owl-theme row">
                    <?php $__currentLoopData = $product_featured; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemFeatured): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="item">
                        <div class="gd-box-info text-center">
                            <div class="product-men women_two bot-gd">
                                <div class="product-googles-info slide-img googles">
                                    <div class="men-pro-item">
                                        <div class="men-thumb-item">

                                            <?php $__currentLoopData = $itemFeatured->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imgf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                            <img src="<?php echo e(URL::asset("assets/images/$imgf->image")); ?>" class="img-fluid"
                                                alt="">
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <div class="men-cart-pro">
                                                <div class="inner-men-cart-pro">

                                                    <a href="<?php echo e(url('product/item',$itemFeatured->id)); ?>"
                                                        class="link-product-add-cart">Quick View</a>
                                                </div>
                                            </div>

                                            <span class="product-new-top">New</span>
                                        </div>
                                        <div class="item-info-product">

                                            <div class="info-product-price">
                                                <div class="grid_meta">
                                                    <div class="product_price">
                                                        <h4>
                                                            <a href="<?php echo e(url('product/item',$itemFeatured->id)); ?>"><?php echo e($itemFeatured->name); ?>

                                                            </a>
                                                        </h4>
                                                        <div class="grid-price mt-2">
                                                            <span class="money "><?php echo e($itemFeatured->amount); ?></span>
                                                        </div>
                                                    </div>
                                                    <ul class="stars">

                                                        <?php for($i = 0; $i < $itemFeatured->star; $i++): ?>
                                                            <li>
                                                                <a href="#">
                                                                    <i class="fa fa-star" aria-hidden="true"></i>
                                                                </a>
                                                            </li>
                                                            <?php endfor; ?>

                                                    </ul>
                                                </div>
                                                <div class="googles single-item hvr-outline-out">
                                                    <form action="#" method="post">
                                                        <input type="hidden" name="cmd" value="_cart">
                                                        <input type="hidden" name="add" value="1">
                                                        <input type="hidden" name="googles_item"
                                                            value="<?php echo e($itemFeatured->name); ?>">
                                                    <input type="hidden" name="amount" value="<?php echo e($itemFeatured->amount); ?>">
                                                    <input type="hidden" name="item_id" value=" <?php echo e($itemFeatured->id); ?>">
                                                        <button type="submit" class="googles-cart pgoogles-cart">
                                                            <i class="fas fa-cart-plus"></i>
                                                        </button>
                                                    </form>

                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
        <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
        <!--//slider-->
    </div>
</section>


<script type="text/javascript">
    $('#search').on('keyup',function(){
    $value=$(this).val();
    $.ajax({
    type : 'get',
    url : '<?php echo e(URL::to('search')); ?>',data:{'search':$value},
    success:function(data){
        $('spans').html(data);
    }
    }
    );
    })
    </script>
    <script type="text/javascript">
    $.ajaxSetup({ headers: { 'csrftoken' : '<?php echo e(csrf_token()); ?>' } });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alshoja/ShoppingCart/resources/views/item.blade.php ENDPATH**/ ?>