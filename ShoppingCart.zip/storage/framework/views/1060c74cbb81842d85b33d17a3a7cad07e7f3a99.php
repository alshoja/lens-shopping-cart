<?php $__env->startSection('content'); ?>
<?php echo $__env->make('users.partials.header', ['title' => __('Our Team')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container-fluid mt--7">
    <div class="row">
        <div class="col-xl-12 order-xl-1">
            <div class="card bg-secondary shadow">
                <div class="card-header bg-white border-0">
                    <div class="row align-items-center">
                        <div class="col-8">
                            <h3 class="mb-0"><?php echo e(__('Manage your Team')); ?></h3>
                        </div>
                        <div class="col-4 text-right">
                            <a href="<?php echo e(url()->previous()); ?>"
                                class="btn btn-sm btn-primary"><?php echo e(__('Back to list')); ?></a>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <form method="post" enctype="multipart/form-data" action="<?php echo e(url('store/team')); ?>" autocomplete="off">
                        <?php echo csrf_field(); ?>

                        <h6 class="heading-small text-muted mb-4"><?php echo e(__('Add Team Members')); ?></h6>
                        <div class="pl-lg-4">
                            <div class="row">
                                    <div class="col-sm">
                                            <div class="form-group<?php echo e($errors->has('name') ? ' has-danger' : ''); ?>">
                                                    
                                                    <input type="text" name="name" id="input-password"
                                                        class="form-control form-control-alternative<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>"
                                                        placeholder="<?php echo e(__('Name')); ?>" value="<?php echo e(old('name')); ?>" required>
            
                                                    <?php if($errors->has('name')): ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                                    </span>
                                                    <?php endif; ?>
                                                </div>
                                    </div>
                                <div class="col-sm">
                                    <div class="form-group<?php echo e($errors->has('position') ? ' has-danger' : ''); ?>">
                                        
                                        <input type="text" name="position" id="input-title"
                                            class="form-control form-control-alternative<?php echo e($errors->has('position') ? ' is-invalid' : ''); ?>"
                                            placeholder="<?php echo e(__('Position')); ?>" value="<?php echo e(old('position')); ?>" required
                                            autofocus>

                                        <?php if($errors->has('position')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('position')); ?></strong>
                                        </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                    <div class="col-sm">
                                            <div class="form-group<?php echo e($errors->has('fb_link') ? ' has-danger' : ''); ?>">
                                                <label class="form-control-label" for="input-email"><?php echo e(__('')); ?></label>          
                                                <div class="input-group mb-3">
                                                        <div class="input-group-prepend">
                                                          <span class="input-group-text" id="basic-addon1"><i class="fab fa-facebook-square"></i></span>
                                                        </div>
                                                        <input type="url" class="form-control" name="fb_link"  placeholder="<?php echo e(__('Facebook url')); ?>" aria-label="facebook url" aria-describedby="basic-addon1">
                                                      </div>
                                                <?php if($errors->has('fb_link')): ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($errors->first('fb_link')); ?></strong>
                                                </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                       
                                <div class="col-sm">
                                        <div class="form-group<?php echo e($errors->has('insta_link') ? ' has-danger' : ''); ?>">
                                                <label class="form-control-label" for="input-email"><?php echo e(__('')); ?></label>          
                                                <div class="input-group mb-3">
                                                        <div class="input-group-prepend">
                                                          <span class="input-group-text" id="basic-addon1"><i class="fab fa-google-plus-g"></i></span>
                                                        </div>
                                                        <input type="url" class="form-control" name="insta_link"  placeholder="<?php echo e(__('Instagram url')); ?>" aria-label="insta url" aria-describedby="basic-addon1">
                                                      </div>
                                                <?php if($errors->has('insta_link')): ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($errors->first('insta_link')); ?></strong>
                                                </span>
                                                <?php endif; ?>
                                            </div>
                                </div>
                                <div class="col-sm">
                                        <div class="form-group<?php echo e($errors->has('twitter_link') ? ' has-danger' : ''); ?>">
                                                <label class="form-control-label" for="input-email"><?php echo e(__('')); ?></label>          
                                                <div class="input-group mb-3">
                                                        <div class="input-group-prepend">
                                                          <span class="input-group-text" id="basic-addon1"><i class="fab fa-twitter"></i></span>
                                                        </div>
                                                        <input type="url" class="form-control" name="twitter_link"  placeholder="<?php echo e(__('Twitter  url')); ?>" aria-label="T url" aria-describedby="basic-addon1">
                                                      </div>
                                                <?php if($errors->has('twitter_link')): ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($errors->first('twitter_link')); ?></strong>
                                                </span>
                                                <?php endif; ?>
                                            </div>
                                </div>
                           
                               
                            </div>
                            <div class="row">
                                    <div class="col-sm-4">
                                           <div class="input-group mb-2">
                                                   <div class="custom-file">
                                                     <input type="file" name="image" class="custom-file-input" id="inputGroupFile02">
                                                     <label class="custom-file-label"  for="inputGroupFile02">Choose Profile Image</label>
                                                   </div>
                                                 
                                                 </div>
                                   </div>
                           </div>
                           
                           
                           
                                  <div>
                                   
                                </div>
                            <div class="text-center">
                                <button type="submit" class="btn btn-success mt-4"><?php echo e(__('Save')); ?></button>
                            </div>

                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    
    <br>
    <div class="table-responsive">
            <div>
                <table class="table align-items-center">
                    <thead class="thead-light">
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">
                                Name
                            </th>
                            <th scope="col">
                             Postion
                            </th>
                            
    
                            <th scope="col"></th>
                        </tr>
                    </thead>
                    <tbody class="list">
                      <?php
                          $i =1
                      ?>
    <?php $__currentLoopData = $team; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                        <tr>
                            <th><?php echo e($i++); ?></th>
                            <th scope="row" class="name">
                                <div class="media align-items-center">
                                    <a href="#" class="avatar rounded-circle mr-3">
                                        <img alt="Image placeholder" src="<?php echo e(URL::asset("assets/$item    ->image")); ?>">
                                    </a>
                                    <div class="media-body">
                                        <span class="mb-0 text-sm"><?php echo e($item->name); ?></span>
                                    </div>
                                </div>
                            </th>
                           
                            <td class="status">
                                <span class="badge badge-dot mr-4">
                                    <i class="bg-warning"></i> <?php echo e($item->position); ?>

                                </span>
                            </td>
                        
    
                            <td class="text-right">
                                <div class="dropdown">
                                    <a class="btn btn-sm btn-icon-only text-light" href="#" role="button"
                                        data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        <i class="fas fa-ellipsis-v"></i>
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                
                                    <a class="dropdown-item" href="<?php echo e(url('show/team',$item->id)); ?>">Edit</a>
                                    <form action="<?php echo e(url('delete/team',$item->id)); ?>" method="post">
                                        <?php echo method_field('delete'); ?>
                                        <?php echo csrf_field(); ?>
                                        <button class="dropdown-item">Delete</button>
                                    </form>
                                    
                                        
                                    </div>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
                    </tbody>
                </table>
            </div>
    
        </div>

    <?php echo $__env->make('layouts.footers.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['title' => __('Our Team')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alshoja/ShoppingCart/resources/views/web-settings/OurTeam/teams.blade.php ENDPATH**/ ?>