<?php

use Faker\Generator as Faker;

$factory->define(App\Models\About::class, function (Faker $faker) {
    return [
        //
    ];
});
