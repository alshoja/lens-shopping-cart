<?php $__env->startSection('content'); ?>
<?php echo $__env->make('users.partials.header', ['title' => __('Manage Stock')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>
<div class="container-fluid mt--7">
    <div class="row">
        <div class="col-xl-12 order-xl-1">
            <div class="card bg-secondary shadow">
                <div class="card-header bg-white border-0">
                    <div class="row align-items-center">
                        <div class="col-8">
                            <h3 class="mb-0"><?php echo e(__('Update/add Stock')); ?></h3>
                        </div>
                        <div class="col-4 text-right">
                            <a href="<?php echo e(route('user.index')); ?>"
                                class="btn btn-sm btn-primary"><?php echo e(__('Back to list')); ?></a>
                        </div>
                    </div>
                </div>
                

            <div class="card-body">
                    <?php if(Session::has('message')): ?>
                    <div class="alert alert-success"><?php echo e(Session::get('message')); ?></div>
                    <?php endif; ?>
                <form method="post" enctype="multipart/form-data" action="<?php echo e(url('store/stock')); ?>" autocomplete="off">
                    <?php echo csrf_field(); ?>

                    <h6 class="heading-small text-muted mb-4"><?php echo e(__('Add Stock')); ?></h6>
                    <div class="pl-lg-4">

                        <div class="row">
                            <div class="col-sm">
                                <div class="form-group<?php echo e($errors->has('name') ? ' has-danger' : ''); ?>">
                                    <label class="form-control-label" for="input-name"><?php echo e(__('Name')); ?></label>
                                    <input type="text" name="name" id="input-title"
                                        class="form-control form-control-alternative<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>"
                                        placeholder="<?php echo e(__('Name')); ?>" value="<?php echo e(old('name')); ?>" required autofocus>

                                    <?php if($errors->has('name')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-sm">
                                <div class="form-group<?php echo e($errors->has('amount') ? ' has-danger' : ''); ?>">
                                    <label class="form-control-label"
                                        for="input-email"><?php echo e(__('Current Price')); ?></label>
                                    <input type="text" name="amount" id="numbervalidate"
                                        class="form-control form-control-alternative<?php echo e($errors->has('amount') ? ' is-invalid' : ''); ?>"
                                        placeholder="<?php echo e(__('Current Price')); ?>" value="<?php echo e(old('amount')); ?>" required>

                                    <?php if($errors->has('amount')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('amount')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-sm">
                                <div class="form-group<?php echo e($errors->has('old_price') ? ' has-danger' : ''); ?>">
                                    <label class="form-control-label" for="input-email"><?php echo e(__('Old Price')); ?></label>
                                    <input type="number" name="old_price" id="numbervalidate"
                                        class="form-control form-control-alternative<?php echo e($errors->has('old_price') ? ' is-invalid' : ''); ?>"
                                        placeholder="<?php echo e(__('Old Price')); ?>" value="<?php echo e(old('old_price')); ?>" required>

                                    <?php if($errors->has('old_price')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('old_price')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-sm">
                                <div class="form-group<?php echo e($errors->has('No of stock') ? ' has-danger' : ''); ?>">
                                    <label class="form-control-label" for="input-email"><?php echo e(__('Stock')); ?></label>
                                    <input type="number" pattern="^-?([0-9]*\?[0-9]+|[0-9]+\?[0-9]*)$" name="stock" id="input-email"
                                        class="form-control form-control-alternative<?php echo e($errors->has('stock') ? ' is-invalid' : ''); ?>"
                                        placeholder="<?php echo e(__('No of Stock')); ?>" value="<?php echo e(old('stock')); ?>" required>

                                    <?php if($errors->has('stock')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('stock')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-sm">
                                <div class="form-group<?php echo e($errors->has('categorie') ? ' has-danger' : ''); ?>">
                                    <label class="form-control-label" for="input-password"><?php echo e(__('Categorie')); ?></label>
                                    <select name="category_id" class="form-control">
                                        <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item->id); ?>" aria-readonly="true"><?php echo e($item->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm">
                            <label class="form-control-label  col-xs-2">Enable Type</label>
                            <div class="col-xs-10">
                                <label class="custom-toggle">
                                    <input type="checkbox" id="myCheck" onclick="myFunction()">
                                    <span class="custom-toggle-slider rounded-circle"></span>
                                </label>
                            </div>
                            <div id="text" style="display:none">
                                <div class="custom-control custom-radio mb-3">
                                    <input type="radio" id="customRadio1" name="customRadio"
                                        class="custom-control-input">
                                    <label class="custom-control-label" for="customRadio1">Something</label>
                                </div>
                            </div>
                        </div>
                        <div class="form-group<?php echo e($errors->has('description') ? ' has-danger' : ''); ?> ">
                            <label class="form-control-label" for="input-email"><?php echo e(__('Description')); ?></label>
                            <textarea name="description"
                                class="form-control form-control-alternative<?php echo e($errors->has('description') ? ' is-invalid' : ''); ?>"
                                id="exampleFormControlTextarea1" value="<?php echo e(old('description')); ?>" rows="3"
                                placeholder="<?php echo e(__('Description about product')); ?>"></textarea>
                            <?php if($errors->has('description')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('description')); ?></strong>
                            </span>
                            <?php endif; ?>
                        </div>

                        <div class="row">

                            <div class="form-group col-md-6">
                                <div class="input-group mb-3">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text">Product Image </span>
                                    </div>
                                    <div class="custom-file">
                                        <input type="file" name="photos[]" required class="custom-file-input"
                                            id="inputGroupFile01" multiple>
                                        <label class="custom-file-label" for="inputGroupFile01"> Can attach more than
                                            one
                                            file</label>
                                    </div>

                                    <?php if($errors->has('photos')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('photos')); ?></strong>

                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <div class="row">

                            <div class="col-sm-3">
                                <label class="form-control-label col-xs-2">Flash Sale</label>
                                <div class="col-xs-10">
                                    <label class="custom-toggle">
                                        <input name="in_flashSale" value="1" type="checkbox" checked>
                                        <span class="custom-toggle-slider rounded-circle"></span>
                                    </label>
                                </div>
                            </div>

                            <div class="col-sm-3">
                                <label class="form-control-label col-xs-2">In Deals</label>
                                <div class="col-xs-10">
                                    <label class="custom-toggle">
                                        <input name="is_inDeals" value="1" type="checkbox" checked>
                                        <span class="custom-toggle-slider rounded-circle"></span>
                                    </label>
                                </div>
                            </div>

                            <div class="col-sm-3">
                                <label class=" form-control-label col-xs-2">Featured Sale</label>
                                <div class="col-xs-10">
                                    <label class="custom-toggle">
                                        <input name="in_Featured_sale" value="1" type="checkbox" checked>
                                        <span class="custom-toggle-slider rounded-circle"></span>
                                    </label>
                                </div>
                            </div>

                            <div class=" text-centre">
                                <button type="submit" class="btn btn-success mt-4"><?php echo e(__('Save')); ?></button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            </form>
        </div>
    </div>
</div>

<br>
<span class="clearfix"></span>
<div class="table-responsive">
    <div>
        <table class="table align-items-center table-flush">
            <thead class="thead-light">
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">
                        Product Name
                    </th>
                    <th scope="col">
                        Price
                    </th>
                    <th scope="col">
                        Old Price
                    </th>

                    
                    <th scope="col">
                        No of Stock
                    </th>
                    <th scope="col">
                        Rating
                    </th>
                    <th scope="col">
                        Category
                    </th>
                    <th scope="col">
                        In Feature Section
                    </th>
                    <th scope="col">
                        In Deals
                    </th>
                    <th scope="col">
                        In Flash Sale
                    </th>
                    <th scope="col"></th>
                </tr>
            </thead>
            <tbody class="list">
                <?php
                $i = 1
                ?>

                <?php $__currentLoopData = $stocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <tr>
                    <th><?php echo e($i++); ?></th>
                    <th scope="row" class="name">
                        <div class="media align-items-center">
                            <a href="#" class="avatar rounded-circle mr-3">
                                <?php $__currentLoopData = $item->productImage; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product_Image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <img alt="Image placeholder" src=<?php echo e(URL::asset("assets/$product_Image->image")); ?>>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                            </a>
                            <div class="media-body">
                                <span class="mb-0 text-sm"><?php echo e($item->name); ?></span>
                            </div>
                        </div>
                    </th>
                    <td class="budget">
                        ₹-/ <?php echo e($item->amount); ?>

                    </td>
                    <td class="status">

                        <span class="mb-0 text-sm">₹-/<?php echo e($item->old_price); ?></span>
                        </span>
                    </td>
                    
                    <td class="budget">
                        ₹-/ <?php echo e($item->stock); ?>

                    </td>
                    <td class="status">
                        <?php if($item->star == 0): ?>
                        <span>Not rated yet</span>
                        <?php endif; ?>
                        <span class="badge badge-dot mr-4">
                            <?php for($i = 0; $i < $item->star; $i++): ?>
                                <i class="far fa-star"></i>
                                <?php endfor; ?>

                        </span>
                    </td>
                    <td class="budget">
                        <?php echo e($item->categorie->name); ?>

                    </td>
                    <td>
                        <div class="avatar-group">
                            <?php if($item->in_Featured_sale): ?>

                            <span class="badge badge-dot mr-4">
                                <i class="bg-success"></i>&#9989
                            </span>
                            <?php else: ?>

                            <span class="badge badge-dot mr-4">
                                <i class="bg-danger"></i>



                                <?php endif; ?>


                        </div>

                    </td>
                    <td>
                        <div class="avatar-group">
                            <?php if($item->is_inDeals): ?>

                            <span class="badge badge-dot mr-4">
                                <i class="bg-success"></i>&#9989
                            </span>
                            <?php else: ?>

                            <span class="badge badge-dot mr-4">
                                <i class="bg-danger"></i>



                                <?php endif; ?>


                        </div>

                    </td>
                    <td>
                        <div class="avatar-group">
                            <?php if($item->in_flashSale): ?>

                            <span class="badge badge-dot mr-4">
                                <i class="bg-success"></i>&#9989
                            </span>
                            <?php else: ?>

                            <span class="badge badge-dot mr-4">
                                <i class="bg-danger"></i>



                                <?php endif; ?>


                        </div>

                    </td>
                    <td class="text-right">
                        <div class="dropdown">
                            <a class="btn btn-sm btn-icon-only text-light" href="#" role="button" data-toggle="dropdown"
                                aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-ellipsis-v"></i>
                            </a>
                            <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                
                                <a class="dropdown-item" href="<?php echo e(url('show/stock',$item->id)); ?>">Edit</a>
                                <form action="<?php echo e(url('delete/stock',$item->id)); ?>" method="post">
                                    <?php echo method_field('delete'); ?>
                                    <?php echo csrf_field(); ?>
                                    <button class="dropdown-item">Delete</button>
                                </form>

                                
                            </div>
                        </div>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
        </table>
    </div>
    <div class="py-6">
        <nav class="d-flex justify-content-end" aria-label="...">
            <?php echo e($stocks->links()); ?>

        </nav>
    </div>

</div>
</div>

<span class="clearfix"></span>


<script>
    function myFunction() {
        var checkBox = document.getElementById("myCheck");
        var text = document.getElementById("text");
        if (checkBox.checked == true) {
            text.style.display = "block";
        } else {
            text.style.display = "none";
        }
    }
</script>
<?php echo $__env->make('layouts.footers.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['title' => __('Stock Management')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/educ/OwnProjects/ShoppingCart/resources/views/web-settings/ManageStock/manageStock.blade.php ENDPATH**/ ?>