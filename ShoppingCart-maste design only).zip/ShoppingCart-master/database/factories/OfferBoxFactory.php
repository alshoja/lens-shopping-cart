<?php

use Faker\Generator as Faker;

$factory->define(App\Models\OfferBox::class, function (Faker $faker) {
    return [
        //
    ];
});
