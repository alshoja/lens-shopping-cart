<?php $__env->startSection('title', 'Contact'); ?>

<?php $__env->startSection('sidebar'); ?>
    ##parent-placeholder-19bd1503d9bad449304cc6b4e977b74bac6cc771##

    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


<!-- banner -->
<div style="
    background: url(<?php echo e(URL::asset("assets/$contact->header_image")); ?>)no-repeat 0px -73px;
    background-size: cover;
    -webkit-background-size: cover;
    -o-background-size: cover;
    -ms-background-size: cover;
    moz-background-size: cover;
    min-height: 180px;
">
    <div class="services-breadcrumb">
        <div class="inner_breadcrumb">

            <ul class="short">
                <li>
                <a href="<?php echo e(url('/')); ?>">Home</a>
                    <i>|</i>
                </li>
                <li>Contact Us</li>
            </ul>
        </div>
    </div>

</div>
<!--//banner -->
</div>
<!--// header_top -->
<!-- top Products -->
<section class="banner-bottom-wthreelayouts py-lg-5 py-3">
<div class="container">
    <h3 class="tittle-w3layouts text-center my-lg-4 my-4">Contact</h3>
    <div class="inner_sec">
    <p class="sub text-center mb-lg-5 mb-3"><?php echo e($contact->title); ?></p>
        <div class="address row">

            <div class="col-lg-4 address-grid">
                <div class="row address-info">
                    <div class="col-md-3 address-left text-center">
                        <i class="far fa-map"></i>
                    </div>
                    <div class="col-md-9 address-right text-left">
                        <h6>Address</h6>
                        <p>
                        <?php echo e($contact->location); ?>

                        </p>
                    </div>
                </div>

            </div>
            <div class="col-lg-4 address-grid">
                <div class="row address-info">
                    <div class="col-md-3 address-left text-center">
                        <i class="far fa-envelope"></i>
                    </div>
                    <div class="col-md-9 address-right text-left">
                        <h6>Email</h6>
                        <p>Email :
                            <a href="<?php echo e($contact->email); ?>"><?php echo e($contact->email); ?></a>

                        </p>
                    </div>

                </div>
            </div>
            <div class="col-lg-4 address-grid">
                <div class="row address-info">
                    <div class="col-md-3 address-left text-center">
                        <i class="fas fa-mobile-alt"></i>
                    </div>
                    <div class="col-md-9 address-right text-left">
                        <h6>Phone</h6>
                        <p><?php echo e($contact->country_code); ?><?php echo e($contact->phone); ?></p>

                    </div>

                </div>
            </div>
        </div>
        <div class="contact_grid_right">
            <form action="#" method="post">
                <div class="row contact_left_grid">
                    <div class="col-md-6 con-left">
                        <div class="form-group">
                            <label class="my-2">Name</label>
                            <input class="form-control" type="text" name="Name" placeholder="" required="">
                        </div>
                        <div class="form-group">
                            <label>Email</label>
                            <input class="form-control" type="email" name="Email" placeholder="" required="">
                        </div>
                        <div class="form-group">
                            <label class="my-2">Subject</label>
                            <input class="form-control" type="text" name="Subject" placeholder="" required="">
                        </div>
                    </div>
                    <div class="col-md-6 con-right">
                        <div class="form-group">
                            <label>Message</label>
                            <textarea id="textarea" placeholder="" required=""></textarea>
                        </div>
                        <input class="form-control" type="submit" value="Submit">

                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
</section>
<div class="contact-map">

<iframe src="<?php echo e($contact->map_iframe_data); ?>"
    class="map" style="border:0" allowfullscreen=""></iframe>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/educ/OwnProjects/ShoppingCart/resources/views/contact.blade.php ENDPATH**/ ?>