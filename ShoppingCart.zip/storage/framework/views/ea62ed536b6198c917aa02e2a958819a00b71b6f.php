<?php $__env->startSection('content'); ?>
<?php echo $__env->make('users.partials.header', ['title' => __('Our Team')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container-fluid mt--7">
    <div class="row">
        <div class="col-xl-12 order-xl-1">
            <div class="card bg-secondary shadow">
                <div class="card-header bg-white border-0">
                    <div class="row align-items-center">
                        <div class="col-8">
                            <h3 class="mb-0"><?php echo e(__('Manage your Team')); ?></h3>
                        </div>
                        <div class="col-4 text-right">
                            <a href="<?php echo e(url()->previous()); ?>"
                                class="btn btn-sm btn-primary"><?php echo e(__('Back to list')); ?></a>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <form method="post" enctype="multipart/form-data" action="<?php echo e(url('patch/team',$team->id)); ?>"
                        autocomplete="off">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('put'); ?>
                        <h6 class="heading-small text-muted mb-4"><?php echo e(__('Update Team Members')); ?></h6>
                        <div class="pl-lg-4">
                            <div class="row">
                                <div class="col-sm">
                                    <div class="form-group<?php echo e($errors->has('name') ? ' has-danger' : ''); ?>">
                                        <label class="form-control-label" for="input-password"><?php echo e(__('Name')); ?></label>
                                        <input type="text" name="name" id="input-password"
                                            class="form-control form-control-alternative<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>"
                                            placeholder="<?php echo e(__('Name')); ?>" value="<?php echo e($team->name); ?>" required>

                                        <?php if($errors->has('name')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('name')); ?></strong>
                                        </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="col-sm">
                                    <div class="form-group<?php echo e($errors->has('position') ? ' has-danger' : ''); ?>">
                                        <label class="form-control-label" for="input-name"><?php echo e(__('Position')); ?></label>
                                        <input type="text" name="position" id="input-title"
                                            class="form-control form-control-alternative<?php echo e($errors->has('position') ? ' is-invalid' : ''); ?>"
                                            placeholder="<?php echo e(__('Position')); ?>" value="<?php echo e($team->position); ?>" required
                                            autofocus>

                                        <?php if($errors->has('position')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('position')); ?></strong>
                                        </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm">
                                    <div class="form-group<?php echo e($errors->has('fb_url') ? ' has-danger' : ''); ?>">
                                        <label class="form-control-label" for="input-email"><?php echo e(__('')); ?></label>
                                        <div class="input-group mb-3">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text" id="basic-addon1"><i
                                                        class="fab fa-facebook-square"></i></span>
                                            </div>
                                            <input type="url" class="form-control" name="fb_link"
                                                value="<?php echo e($team->fb_link); ?>" placeholder="<?php echo e(__('Facebook url')); ?>"
                                                aria-label="facebook url" aria-describedby="basic-addon1">
                                        </div>
                                        <?php if($errors->has('fb_url')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('fb_url')); ?></strong>
                                        </span>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <div class="col-sm">
                                    <div class="form-group<?php echo e($errors->has('insta_url') ? ' has-danger' : ''); ?>">
                                        <label class="form-control-label" for="input-email"><?php echo e(__('')); ?></label>
                                        <div class="input-group mb-3">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text" id="basic-addon1"><i
                                                        class="fab fa-google-plus-g"></i></span>
                                            </div>
                                            <input type="url" class="form-control" name="insta_link"
                                                value="<?php echo e($team->insta_link); ?>" placeholder="<?php echo e(__('Instagram url')); ?>"
                                                aria-label="insta url" aria-describedby="basic-addon1">
                                        </div>
                                        <?php if($errors->has('insta_url')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('insta_url')); ?></strong>
                                        </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="col-sm">
                                    <div class="form-group<?php echo e($errors->has('twitter_url') ? ' has-danger' : ''); ?>">
                                        <label class="form-control-label" for="input-email"><?php echo e(__('')); ?></label>
                                        <div class="input-group mb-3">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text" id="basic-addon1"><i
                                                        class="fab fa-twitter"></i></span>
                                            </div>
                                            <input type="url" class="form-control" name="twitter_link"
                                                value="<?php echo e($team->twitter_link); ?>" placeholder="<?php echo e(__('Twitter  url')); ?>"
                                                aria-label="T url" aria-describedby="basic-addon1">
                                        </div>
                                        <?php if($errors->has('twitter_url')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('twitter_url')); ?></strong>
                                        </span>
                                        <?php endif; ?>
                                    </div>
                                </div>


                            </div>
                            <div class="row">
                                <div class="col-sm-4">
                                    <div class="input-group mb-2">
                                        <div class="custom-file">
                                            <input type="file" name="image" class="custom-file-input"
                                                id="inputGroupFile02">
                                            <label class="custom-file-label" for="inputGroupFile02">Choose Profile
                                                Image</label>
                                        </div>

                                    </div>
                                </div>
                                <div class="col-sm-2 col-sm-offset-1">
                                    <div class="input-group mb-5">
                                        <div class="input-group-prepend">
                                            <img src="<?php echo e(URL::asset("assets/$team->image")); ?>" class="img-thumbnail"
                                                alt="Cinque Terre" width="104" height="76">
                                        </div>
                                    </div>
                                </div>

                            </div>



                            <div>

                            </div>
                            <div class="text-center">
                                <button type="submit" class="btn btn-success mt-4"><?php echo e(__('Update')); ?></button>
                            </div>

                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    
    <br>


    <?php echo $__env->make('layouts.footers.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['title' => __('Our Team')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/educ/OwnProjects/ShoppingCart/resources/views/web-settings/OurTeam/editteam.blade.php ENDPATH**/ ?>