<?php $__env->startSection('content'); ?>
<?php echo $__env->make('users.partials.header', ['title' => __('Update Product')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>

<div class="container-fluid mt--7">
    <div class="row">
        <div class="col-xl-12 order-xl-1">
            <div class="card bg-secondary shadow">
                <div class="card-header bg-white border-0">
                    <div class="row align-items-center">
                        <div class="col-8">
                            <h3 class="mb-0"><?php echo e(__('Update/add Stock')); ?></h3>
                        </div>
                        <div class="col-4 text-right">
                            <a href="<?php echo e(URL::previous()); ?>"
                                class="btn btn-sm btn-primary"><?php echo e(__('Back to list')); ?></a>
                        </div>
                    </div>
                </div>
                

            <div class="card-body">
                    <?php if(Session::has('message')): ?>
                    <div class="alert alert-success"><?php echo e(Session::get('message')); ?></div>
                    <?php endif; ?>
                <form method="post" enctype="multipart/form-data" action="<?php echo e(url('update/stock',$stocks->id)); ?>" autocomplete="off">
                    <?php echo csrf_field(); ?>
<?php echo method_field('put'); ?>
                    <h6 class="heading-small text-muted mb-4"><?php echo e(__('Update Product')); ?></h6>
                    <div class="pl-lg-4">

                        <div class="row">
                            <div class="col-sm">
                                <div class="form-group<?php echo e($errors->has('name') ? ' has-danger' : ''); ?>">
                                    <label class="form-control-label" for="input-name"><?php echo e(__('Name')); ?></label>
                                    <input type="text" name="name" id="input-title"
                                        class="form-control form-control-alternative<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>"
                                        placeholder="<?php echo e(__('Name')); ?>" value="<?php echo e($stocks->name); ?>" required autofocus>

                                    <?php if($errors->has('name')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-sm">
                                <div class="form-group<?php echo e($errors->has('amount') ? ' has-danger' : ''); ?>">
                                    <label class="form-control-label"
                                        for="input-email"><?php echo e(__('Current Price')); ?></label>
                                    <input type="text" name="amount" id="numbervalidate"
                                        class="form-control form-control-alternative<?php echo e($errors->has('amount') ? ' is-invalid' : ''); ?>"
                                        placeholder="<?php echo e(__('Current Price')); ?>" value="<?php echo e($stocks->amount); ?>" required>

                                    <?php if($errors->has('amount')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('amount')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-sm">
                                <div class="form-group<?php echo e($errors->has('old_price') ? ' has-danger' : ''); ?>">
                                    <label class="form-control-label" for="input-email"><?php echo e(__('Old Price')); ?></label>
                                    <input type="number" name="old_price" id="numbervalidate"
                                        class="form-control form-control-alternative<?php echo e($errors->has('old_price') ? ' is-invalid' : ''); ?>"
                                        placeholder="<?php echo e(__('Old Price')); ?>" value="<?php echo e($stocks->old_price); ?>" required>

                                    <?php if($errors->has('old_price')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('old_price')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-sm">
                                <div class="form-group<?php echo e($errors->has('No of stock') ? ' has-danger' : ''); ?>">
                                    <label class="form-control-label" for="input-email"><?php echo e(__('Stock')); ?></label>
                                    <input type="number" pattern="^-?([0-9]*\?[0-9]+|[0-9]+\?[0-9]*)$" name="stock" id="input-email"
                                        class="form-control form-control-alternative<?php echo e($errors->has('stock') ? ' is-invalid' : ''); ?>"
                                        placeholder="<?php echo e(__('No of Stock')); ?>" value="<?php echo e($stocks->stock); ?>" required>

                                    <?php if($errors->has('stock')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('stock')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-sm">
                                <div class="form-group<?php echo e($errors->has('categorie') ? ' has-danger' : ''); ?>">
                                    <label class="form-control-label" for="input-password"><?php echo e(__('Categorie')); ?></label>
                                    <select name="category_id" class="form-control">
                                            <option value="<?php echo e($stocks->id); ?>" aria-readonly="true"><?php echo e($stocks->name); ?></option>

                                        <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item->id); ?>" aria-readonly="true"><?php echo e($item->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm">
                            <label class="form-control-label  col-xs-2">Enable Type</label>
                            <div class="col-xs-10">
                                <label class="custom-toggle">
                                    <input type="checkbox" id="myCheck" onclick="myFunction()">
                                    <span class="custom-toggle-slider rounded-circle"></span>
                                </label>
                            </div>
                            <div id="text" style="display:none">
                                <div class="custom-control custom-radio mb-3">
                                    <input type="radio" id="customRadio1" name="customRadio"
                                        class="custom-control-input">
                                    <label class="custom-control-label" for="customRadio1">Something</label>
                                </div>
                            </div>
                        </div>
                        <div class="form-group<?php echo e($errors->has('description') ? ' has-danger' : ''); ?> ">
                            <label class="form-control-label" for="input-email"><?php echo e(__('Description')); ?></label>
                            <textarea name="description"
                                class="form-control form-control-alternative<?php echo e($errors->has('description') ? ' is-invalid' : ''); ?>"
                                id="exampleFormControlTextarea1" value="<?php echo e(old('description')); ?>" rows="3"
                        placeholder="<?php echo e(__('Description about product')); ?>"><?php echo e($stocks->description); ?></textarea>
                            <?php if($errors->has('description')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('description')); ?></strong>
                            </span>
                            <?php endif; ?>
                        </div>

                        <div class="row">

                            <div class="form-group col-md-6">
                                <div class="input-group mb-3">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text">Product Image </span>
                                    </div>
                                    <div class="custom-file">
                                        <input type="file" name="photos[]"  class="custom-file-input"
                                            id="inputGroupFile01" multiple>
                                        <label class="custom-file-label" for="inputGroupFile01"> Can attach more than
                                            one
                                            file</label>
                                    </div>

                                    <?php if($errors->has('photos')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('photos')); ?></strong>

                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <div class="row">

                            <div class="col-sm-3">
                                <label class="form-control-label col-xs-2">Flash Sale</label>
                                <div class="col-xs-10">
                                    <label class="custom-toggle">
                                        <?php if($stocks->in_flashSale == 1): ?>
                                        <input name="in_flashSale" value="1" type="checkbox" checked>

                                        <?php else: ?>
                                        <input name="in_flashSale" value="1" type="checkbox">
                                        <?php endif; ?>

                                        <span class="custom-toggle-slider rounded-circle"></span>
                                    </label>
                                </div>
                            </div>

                            <div class="col-sm-3">
                                <label class="form-control-label col-xs-2">In Deals</label>
                                <div class="col-xs-10">
                                    <label class="custom-toggle">
                                            <?php if($stocks->is_inDeals == 1): ?>
                                            <input name="is_inDeals" value="1" type="checkbox" checked>

                                            <?php else: ?>
                                            <input name="is_inDeals" value="1" type="checkbox">
                                            <?php endif; ?>
                                        <span class="custom-toggle-slider rounded-circle"></span>
                                    </label>
                                </div>
                            </div>

                            <div class="col-sm-3">
                                <label class=" form-control-label col-xs-2">Featured Sale</label>
                                <div class="col-xs-10">
                                    <label class="custom-toggle">
                                            <?php if($stocks->in_Featured_sale == 1): ?>
                                            <input name="in_Featured_sale" value="1" type="checkbox" checked>

                                            <?php else: ?>
                                            <input name="in_Featured_sale" value="1" type="checkbox">
                                            <?php endif; ?>
                                        <span class="custom-toggle-slider rounded-circle"></span>
                                    </label>
                                </div>
                            </div>

                            <div class=" text-centre">
                                <button type="submit" class="btn btn-success mt-4"><?php echo e(__('Save')); ?></button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            </form>
        </div>
    </div>
</div>

<br>
<span class="clearfix"></span>

</div>

<span class="clearfix"></span>


<div class="row">
    <div class="col-md-12" >
<div class="container" style="width: 40%">
    <?php
        $i=1
    ?>
    <?php
    $max =  count($stocks->images)
 ?>
 <?php if($max==0): ?>
 <div class="mySlides">
    <div class="numbertext">No images found</div>
    <div class="imgs">
    <img src="<?php echo e(URL::asset("argon/img/noimage.gif")); ?>" style="width:100%">
    </div>
    <marquee width="40%" direction="left" height="30%">
       Nothing found..! Please add some images
        </marquee>
  </div>
 <?php else: ?>
    <?php $__currentLoopData = $stocks->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="mySlides">
  <div class="numbertext"><?php echo e($i++); ?> / <?php echo e($max); ?>

        <div class="row" style="margin: 20px">
                <div class="sm">
                    <!-- Button trigger modal -->
<button type="button" class="btn btn-sm btn-primary" data-toggle="modal" data-target="#exampleModal">
  Update
</button>
    </div>
    <div class="sm">

        <form action="<?php echo e(url('delete/stock/image',$item->id)); ?>" method="post">
            <?php echo method_field('delete'); ?>
            <?php echo csrf_field(); ?>
        <button type="submit" class="btn btn-sm btn-danger mt-4 ">Delete</button>
        </form>
    </div>
</div>
  </div>

    <img src="<?php echo e(URL::asset("assets/$item->image")); ?>" style="width:100%">

  </div>
  
  <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Update Image</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
            <form action="<?php echo e(url('update/stock/image',$item->product_id)); ?>" enctype="multipart/form-data" method="post">
                <?php echo method_field('put'); ?>
                <?php echo csrf_field(); ?>
                       <div class="input-group mb-3">
                            <div class="input-group-prepend">
                                <span class="input-group-text">Product Image </span>
                            </div>
                            <div class="custom-file">
                                <input type="file" name="photo" required class="custom-file-input"
                                    id="inputGroupFile01" multiple>
                                <label class="custom-file-label" for="inputGroupFile01"> File</label>
                            </div>

                            <?php if($errors->has('photos')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('photos')); ?></strong>

                            </span>
                            <?php endif; ?>
                        </div>
                        <button type="submit" class="btn btn-primary">Save changes</button>
                    </form>
      </div>

      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <?php endif; ?>
  <a class="prev" onclick="plusSlides(-1)">❮</a>
  <a class="next" onclick="plusSlides(1)">❯</a>

  <div class="caption-container">

    <p  id="caption"></p>
  </div>

  <div class="row">
      <?php
          $sno =1
      ?>
        <?php $__currentLoopData = $stocks->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="column">
      <img class="demo cursor" src="<?php echo e(URL::asset("assets/$item->image")); ?>" style="width:100%" onclick="currentSlide(<?php echo e($sno++); ?>)" alt="<?php echo e($item->image); ?>">
    </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
</div>
    </div>
</div>
<script>
        var slideIndex = 1;
        showSlides(slideIndex);

        function plusSlides(n) {
          showSlides(slideIndex += n);
        }

        function currentSlide(n) {
          showSlides(slideIndex = n);
        }

        function showSlides(n) {
          var i;
          var slides = document.getElementsByClassName("mySlides");
          var dots = document.getElementsByClassName("demo");
          var captionText = document.getElementById("caption");
          if (n > slides.length) {slideIndex = 1}
          if (n < 1) {slideIndex = slides.length}
          for (i = 0; i < slides.length; i++) {
              slides[i].style.display = "none";
          }
          for (i = 0; i < dots.length; i++) {
              dots[i].className = dots[i].className.replace(" active", "");
          }
          slides[slideIndex-1].style.display = "block";
          dots[slideIndex-1].className += " active";
          captionText.innerHTML = dots[slideIndex-1].alt;
        }
        </script>

<script>
    function myFunction() {
        var checkBox = document.getElementById("myCheck");
        var text = document.getElementById("text");
        if (checkBox.checked == true) {
            text.style.display = "block";
        } else {
            text.style.display = "none";
        }
    }
</script>
<?php echo $__env->make('layouts.footers.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['title' => __('Stock Management')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alshoja/ShoppingCart/resources/views/web-settings/ManageStock/editmanageStock.blade.php ENDPATH**/ ?>