<?php $__env->startSection('content'); ?>
<?php echo $__env->make('users.partials.header', ['title' => __('Update About')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container-fluid mt--7">
    <div class="row">
        <div class="col-xl-12 order-xl-1">
            <div class="card bg-secondary shadow">
                <div class="card-header bg-white border-0">
                    <div class="row align-items-center">
                        <div class="col-8">
                            <h3 class="mb-0"><?php echo e(__('About Your Company')); ?></h3>
                        </div>
                        <div class="col-4 text-right">
                            <a href="<?php echo e(route('user.index')); ?>"
                                class="btn btn-sm btn-primary"><?php echo e(__('Back to list')); ?></a>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <form method="post" enctype="multipart/form-data" action="<?php echo e(route('web-settings.About.about')); ?>" autocomplete="off">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('put'); ?>
                        <h6 class="heading-small text-muted mb-4"><?php echo e(__('About information')); ?></h6>
                        <div class="pl-lg-4">
                            <div class="row">
                                    <div class="col-sm">
                                            <div class="form-group<?php echo e($errors->has('heading') ? ' has-danger' : ''); ?>">
                                                    <label class="form-control-label" for="input-password"><?php echo e(__('Heading')); ?></label>
                                                    <input type="text" name="heading" id="input-password"
                                                        class="form-control form-control-alternative<?php echo e($errors->has('heading') ? ' is-invalid' : ''); ?>"
                                                        placeholder="<?php echo e(__('Title')); ?>" value="<?php echo e($about->heading); ?>" required>
            
                                                    <?php if($errors->has('heading')): ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($errors->first('heading')); ?></strong>
                                                    </span>
                                                    <?php endif; ?>
                                                </div>
                                    </div>
                                <div class="col-sm">
                                    <div class="form-group<?php echo e($errors->has('button_value') ? ' has-danger' : ''); ?>">
                                        <label class="form-control-label" for="input-name"><?php echo e(__('Button Value')); ?></label>
                                        <input type="text" name="button_value" id="input-title"
                                            class="form-control form-control-alternative<?php echo e($errors->has('button_value') ? ' is-invalid' : ''); ?>"
                                            placeholder="<?php echo e(__('Button Value')); ?>" value="<?php echo e($about->button_value); ?>" required
                                            autofocus>

                                        <?php if($errors->has('button_value')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('button_value')); ?></strong>
                                        </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                    <div class="col-sm">
                                            <div class="form-group<?php echo e($errors->has('fb_url') ? ' has-danger' : ''); ?>">
                                                <label class="form-control-label" for="input-email"><?php echo e(__('')); ?></label>          
                                                <div class="input-group mb-3">
                                                        <div class="input-group-prepend">
                                                          <span class="input-group-text" id="basic-addon1"><i class="fab fa-facebook-square"></i></span>
                                                        </div>
                                                        <input type="url" class="form-control" name="fb_url" value="<?php echo e($about->fb_url); ?>"  placeholder="<?php echo e(__('Facebook url')); ?>" aria-label="facebook url" aria-describedby="basic-addon1">
                                                      </div>
                                                <?php if($errors->has('fb_url')): ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($errors->first('fb_url')); ?></strong>
                                                </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="col-sm">
                                                <div class="form-group<?php echo e($errors->has('link_url') ? ' has-danger' : ''); ?>">
                                                        <label class="form-control-label" for="input-email"><?php echo e(__('')); ?></label>          
                                                        <div class="input-group mb-3">
                                                                <div class="input-group-prepend">
                                                                  <span class="input-group-text" id="basic-addon1"><i class="fab fa-linkedin-in"></i></span>
                                                                </div>
                                                                <input type="url" class="form-control" name="link_url" value="<?php echo e($about->link_url); ?>"  placeholder="<?php echo e(__('Linkdin url')); ?>" aria-label="facebook url" aria-describedby="basic-addon1">
                                                              </div>
                                                        <?php if($errors->has('link_url')): ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($errors->first('link_url')); ?></strong>
                                                        </span>
                                                        <?php endif; ?>
                                                    </div>
                                        </div>
                                <div class="col-sm">
                                        <div class="form-group<?php echo e($errors->has('google_url') ? ' has-danger' : ''); ?>">
                                                <label class="form-control-label" for="input-email"><?php echo e(__('')); ?></label>          
                                                <div class="input-group mb-3">
                                                        <div class="input-group-prepend">
                                                          <span class="input-group-text" id="basic-addon1"><i class="fab fa-google-plus-g"></i></span>
                                                        </div>
                                                        <input type="url" class="form-control" name="google_url" value="<?php echo e($about->google_url); ?>"  placeholder="<?php echo e(__('Google+  url')); ?>" aria-label="G url" aria-describedby="basic-addon1">
                                                      </div>
                                                <?php if($errors->has('google_url')): ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($errors->first('google_url')); ?></strong>
                                                </span>
                                                <?php endif; ?>
                                            </div>
                                </div>
                                <div class="col-sm">
                                        <div class="form-group<?php echo e($errors->has('twitter_url') ? ' has-danger' : ''); ?>">
                                                <label class="form-control-label" for="input-email"><?php echo e(__('')); ?></label>          
                                                <div class="input-group mb-3">
                                                        <div class="input-group-prepend">
                                                          <span class="input-group-text" id="basic-addon1"><i class="fab fa-twitter"></i></span>
                                                        </div>
                                                        <input type="url" class="form-control" name="twitter_url" value="<?php echo e($about->twitter_url); ?>"  placeholder="<?php echo e(__('Twitter  url')); ?>" aria-label="T url" aria-describedby="basic-addon1">
                                                      </div>
                                                <?php if($errors->has('twitter_url')): ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($errors->first('twitter_url')); ?></strong>
                                                </span>
                                                <?php endif; ?>
                                            </div>
                                </div>
                                <div class="col-sm">
                                        <div class="form-group<?php echo e($errors->has('rss_link') ? ' has-danger' : ''); ?>">
                                                <label class="form-control-label" for="input-email"><?php echo e(__('')); ?></label>          
                                                <div class="input-group mb-3">
                                                        <div class="input-group-prepend">
                                                          <span class="input-group-text" id="basic-addon1"><i class="fas fa-rss"></i></span>
                                                        </div>
                                                        <input type="url" class="form-control" name="rss_link" value="<?php echo e($about->rss_link); ?>"  placeholder="<?php echo e(__('Rss Feed  url')); ?>" aria-label="R url" aria-describedby="basic-addon1">
                                                      </div>
                                                <?php if($errors->has('rss_link')): ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($errors->first('rss_link')); ?></strong>
                                                </span>
                                                <?php endif; ?>
                                            </div>
                                </div>
                                <div class="col-sm">
                                        <div class="form-group<?php echo e($errors->has('other') ? ' has-danger' : ''); ?>">
                                                <label class="form-control-label" for="input-email"><?php echo e(__('')); ?></label>          
                                                <div class="input-group mb-3">
                                                        <div class="input-group-prepend">
                                                          <span class="input-group-text" id="basic-addon1"><i class="fas fa-braille"></i></span>
                                                        </div>
                                                        <input type="url" class="form-control" name="other" value="<?php echo e($about->other); ?>"  placeholder="<?php echo e(__('Other Feed  url')); ?>" aria-label="O url" aria-describedby="basic-addon1">
                                                      </div>
                                                <?php if($errors->has('other')): ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($errors->first('other')); ?></strong>
                                                </span>
                                                <?php endif; ?>
                                            </div>
                                </div>
                            </div>
                            <div class="row">
                                    <div class="col-sm-6">
                                           <div class="input-group mb-2">
                                                   <div class="custom-file">
                                                     <input type="file" name="image" class="custom-file-input" id="inputGroupFile02">
                                                     <label class="custom-file-label" for="inputGroupFile02">Choose Banner Image</label>
                                                   </div>
                                                 
                                                 </div>
                                   </div>
                           </div>
                            <div class="row">
                                    <div class="col-sm-6 mt-sm-4 mb-sm-5">
                                    <div class="form-group<?php echo e($errors->has('description') ? ' has-danger' : ''); ?>">
                                            <label class="form-control-label" for="input-email"><?php echo e(__('Description')); ?></label> 
                                            <textarea name="description"
                                                class="form-control form-control-alternative<?php echo e($errors->has('description') ? ' is-invalid' : ''); ?>"
                                                id="exampleFormControlTextarea1"  rows="3"
                                    placeholder="<?php echo e(__('A brief description about your company :)')); ?>"><?php echo e($about->description); ?></textarea>
                                            <?php if($errors->has('description')): ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($errors->first('description')); ?></strong>
                                            </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-sm">
                                            <label class="form-control-label" for="input-email"><?php echo e(__('Banner Image')); ?></label>       
                                            <div class="input-group-prepend">
                                                <img src="<?php echo e(URL::asset("assets/$about->image")); ?>" class="img-thumbnail" alt="technalatus" width="304" height="236">
                                                  </div>
                                            </div>
                           </div>
                           
                           
                                  <div>
                                   
                                </div>
                            <div class="text-center">
                                <button type="submit" class="btn btn-success mt-4"><?php echo e(__('Save')); ?></button>
                            </div>

                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    


    <?php echo $__env->make('layouts.footers.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['title' => __('Update About')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/educ/OwnProjects/ShoppingCart/resources/views/web-settings/About/about.blade.php ENDPATH**/ ?>