
            @include('includes.header')     
       
            @section('sidebar')
       
    
      

        <div class="container">
            @yield('content')
        </div>

        @include('includes.footer')  
