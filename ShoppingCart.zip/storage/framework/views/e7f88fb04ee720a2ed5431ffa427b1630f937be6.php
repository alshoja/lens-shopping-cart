<?php $__env->startSection('content'); ?>
<?php echo $__env->make('users.partials.header', ['title' => __('Update Contact')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container-fluid mt--7">
    <div class="row">
        <div class="col-xl-12 order-xl-1">
            <div class="card bg-secondary shadow">
                <div class="card-header bg-white border-0">
                    <div class="row align-items-center">
                        <div class="col-8">
                            <h3 class="mb-0"><?php echo e(__('Contact Details')); ?></h3>
                        </div>
                        <div class="col-4 text-right">
                            <a href="<?php echo e(url()->previous()); ?>"
                                class="btn btn-sm btn-primary"><?php echo e(__('Back')); ?></a>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <form method="post" action="<?php echo e(route('web-settings.Contact.contact')); ?>" enctype="multipart/form-data" autocomplete="off">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('put'); ?>
                        <h6 class="heading-small text-muted mb-4"><?php echo e(__('Update Contact information')); ?></h6>
                        <div class="pl-lg-4">
                            <div class="row">
                                    <div class="col-sm">
                                            <div class="form-group<?php echo e($errors->has('title') ? ' has-danger' : ''); ?>">
                                                    <label class="form-control-label" for="input-password"><?php echo e(__('Title')); ?></label>
                                                    <input type="text" name="title" id="input-password"
                                                        class="form-control form-control-alternative<?php echo e($errors->has('title') ? ' is-invalid' : ''); ?>"
                                            placeholder="<?php echo e(__('Title')); ?>" value="<?php echo e($contact->title); ?>" required>

                                                    <?php if($errors->has('title')): ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($errors->first('title')); ?></strong>
                                                    </span>
                                                    <?php endif; ?>
                                                </div>
                                    </div>
                                    <div class="col-sm">
                                        <div class="form-group<?php echo e($errors->has('country_code') ? ' has-danger' : ''); ?>">
                                                <label class="form-control-label" for="input-password"><?php echo e(__('Country code')); ?></label>
                                                <input type="text" name="country_code" id="input-password"
                                                    class="form-control form-control-alternative<?php echo e($errors->has('country_code') ? ' is-invalid' : ''); ?>"
                                        placeholder="<?php echo e(__('country_code')); ?>" value="<?php echo e($contact->country_code); ?>" required>

                                                <?php if($errors->has('country_code')): ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($errors->first('country_code')); ?></strong>
                                                </span>
                                                <?php endif; ?>
                                            </div>
                                </div>
                                <div class="col-sm">
                                    <div class="form-group<?php echo e($errors->has('phone') ? ' has-danger' : ''); ?>">
                                        <label class="form-control-label" for="input-name"><?php echo e(__('Phone')); ?></label>
                                        <input type="text" name="phone" id="input-title"
                                            class="form-control form-control-alternative<?php echo e($errors->has('phone') ? ' is-invalid' : ''); ?>"
                                            placeholder="<?php echo e(__('Phone')); ?>" value="<?php echo e($contact->phone); ?>" required
                                            autofocus>
                                        <?php if($errors->has('phone')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('phone')); ?></strong>
                                        </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="col-sm">
                                    <div class="form-group<?php echo e($errors->has('location') ? ' has-danger' : ''); ?>">
                                        <label class="form-control-label" for="input-email"><?php echo e(__('Location')); ?></label>
                                        <input type="text" name="location" id="input-email"
                                            class="form-control form-control-alternative<?php echo e($errors->has('location') ? ' is-invalid' : ''); ?>"
                                            placeholder="<?php echo e(__('Location')); ?>" value="<?php echo e($contact->location); ?>" required>

                                        <?php if($errors->has('location')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('location')); ?></strong>
                                        </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="col-sm">
                                    <div class="form-group<?php echo e($errors->has('email') ? ' has-danger' : ''); ?>">
                                        <label class="form-control-label" for="input-password"><?php echo e(__('Email')); ?></label>
                                        <input type="email" name="email" id="input-password"
                                            class="form-control form-control-alternative<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>"
                                            placeholder="<?php echo e(__('Email')); ?>" value="<?php echo e($contact->email); ?>" required>

                                        <?php if($errors->has('email')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('email')); ?></strong>
                                        </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm">
                                    <div class="form-group<?php echo e($errors->has('footer_subscribing_data') ? ' has-danger' : ''); ?>">
                                        <label class="form-control-label" for="input-password"><?php echo e(__('Footer Subscribing Data')); ?></label>
                                        <input type="text" name="footer_subscribing_data" id="input-password"
                                            class="form-control form-control-alternative<?php echo e($errors->has('footer_subscribing_data') ? ' is-invalid' : ''); ?>"
                                            placeholder="<?php echo e(__('Subscribing Message')); ?>" value="<?php echo e($contact->footer_subscribing_data); ?>" required>

                                        <?php if($errors->has('footer_subscribing_data')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('footer_subscribing_data')); ?></strong>
                                        </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="col-sm">
                                        <div class="form-group<?php echo e($errors->has('rights_data') ? ' has-danger' : ''); ?>">
                                                <label class="form-control-label" for="input-password"><?php echo e(__('Rights Data')); ?></label>
                                                <input type="text" name="rights_data" id="input-password"
                                                    class="form-control form-control-alternative<?php echo e($errors->has('rights_data') ? ' is-invalid' : ''); ?>"
                                                    placeholder="<?php echo e(__('® Rights Message')); ?>" value="<?php echo e($contact->rights_data); ?>" required>

                                                <?php if($errors->has('rights_data')): ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($errors->first('rights_data')); ?></strong>
                                                </span>
                                                <?php endif; ?>
                                            </div>
                                </div>
                                <div class="col-sm">
                                        <div class="form-group<?php echo e($errors->has('rights_company_name') ? ' has-danger' : ''); ?>">
                                                <label class="form-control-label" for="input-password"><?php echo e(__('Rights company Name')); ?></label>
                                                <input type="text" name="rights_company_name" id="input-password"
                                                    class="form-control form-control-alternative<?php echo e($errors->has('rights_company_name') ? ' is-invalid' : ''); ?>"
                                                    placeholder="<?php echo e(__('Company name')); ?>" value="<?php echo e($contact->rights_company_name); ?>"  required>

                                                <?php if($errors->has('rights_company_name')): ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($errors->first('rights_company_name')); ?></strong>
                                                </span>
                                                <?php endif; ?>
                                            </div>
                                </div>
                                <div class="col-sm">
                                        <div class="form-group<?php echo e($errors->has('company_url') ? ' has-danger' : ''); ?>">
                                                <label class="form-control-label" for="input-password"><?php echo e(__('Website')); ?></label>
                                                <input type="url" name="company_url" id="input-password"
                                                    class="form-control form-control-alternative<?php echo e($errors->has('company_url') ? ' is-invalid' : ''); ?>"
                                                    placeholder="<?php echo e(__('http://website.com')); ?>" value="<?php echo e($contact->company_url); ?>" required>

                                                <?php if($errors->has('company_url')): ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($errors->first('company_url')); ?></strong>
                                                </span>
                                                <?php endif; ?>
                                            </div>
                                </div>
                            </div>
                            <div class="row">
                                    <div class="col-sm-6">
                                           <div class="input-group mb-2">
                                                   <div class="custom-file">
                                                     <input type="file" name="header_image" class="custom-file-input" id="inputGroupFile02">
                                                     <label class="custom-file-label" for="inputGroupFile02">Choose Banner Image</label>
                                                   </div>

                                                 </div>
                                   </div>
                           </div>
                            <div class="row">
                                    <div class="col-sm-6 mt-sm-4 mb-sm-5">
                                    <div class="form-group<?php echo e($errors->has('map_iframe_data') ? ' has-danger' : ''); ?>">
                                            <label class="form-control-label" for="input-email"><?php echo e(__('Iframe Data')); ?></label>
                                            <textarea name="map_iframe_data"
                                                class="form-control form-control-alternative<?php echo e($errors->has('map_iframe_data') ? ' is-invalid' : ''); ?>"
                                                id="exampleFormControlTextarea1" value="<?php echo e(old('description')); ?>" rows="3"
                                                placeholder="<?php echo e(__('  <iframe src = "/html/menu.htm" width = "555" height = "200"></iframe>')); ?>"><?php echo e($contact->map_iframe_data); ?></textarea>
                                            <?php if($errors->has('map_iframe_data')): ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($errors->first('map_iframe_data')); ?></strong>
                                            </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>

                                    <div class="col-sm">
                                        <div class="input-group-prepend">
                                            <img src="<?php echo e(URL::asset("assets/$contact->header_image")); ?>" class="img-thumbnail" alt="Cinque Terre" width="304" height="236">
                                              </div>
                                        </div>
                           </div>


                                  <div>

                                </div>
                            <div class="text-center">
                                <button type="submit" class="btn btn-success mt-4"><?php echo e(__('Save')); ?></button>
                            </div>

                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    


    <?php echo $__env->make('layouts.footers.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['title' => __('Update Contact')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alshoja/ShoppingCart/resources/views/web-settings/Contact/contact.blade.php ENDPATH**/ ?>