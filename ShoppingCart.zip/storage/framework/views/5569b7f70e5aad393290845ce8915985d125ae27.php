<?php $__env->startSection('content'); ?>
<?php echo $__env->make('users.partials.header', ['title' => __('Offer Timer')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container-fluid mt--7">
    <div class="row">
        <div class="col-xl-12 order-xl-1">
            <div class="card bg-secondary shadow">
                <div class="card-header bg-white border-0">
                    <div class="row align-items-center">
                        <div class="col-8">
                            <h3 class="mb-0"><?php echo e(__('Update timer')); ?></h3>
                        </div>
                        <div class="col-4 text-right">
                            <a href="<?php echo e(route('user.index')); ?>"
                                class="btn btn-sm btn-primary"><?php echo e(__('Back to list')); ?></a>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <form method="post" enctype="multipart/form-data" action="<?php echo e(url('update/home/timer')); ?>" autocomplete="off">
                        <?php echo csrf_field(); ?>
<?php echo method_field('put'); ?>
                        <h6 class="heading-small text-muted mb-4"><?php echo e(__(' Offer Timer')); ?></h6>
                        <div class="pl-lg-4">
                            <div class="row">
                                <div class="col-sm">
                                    <div class="form-group<?php echo e($errors->has('title') ? ' has-danger' : ''); ?>">
                                        <label class="form-control-label" for="input-password"><?php echo e(__('Title for Timer')); ?></label>
                                       
                                        <input type="text" name="title" id="input-password"
                                            class="form-control form-control-alternative<?php echo e($errors->has('title') ? ' is-invalid' : ''); ?>"
                                    placeholder="<?php echo e(__('Title')); ?>" value="<?php echo e($timer->title); ?>" required>

                                        <?php if($errors->has('title')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('title')); ?></strong>
                                        </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="col-sm">
                                    <div class="form-group<?php echo e($errors->has('timestamp') ? ' has-danger' : ''); ?>">
                                        <label class="form-control-label" for="input-password"><?php echo e(__('Time')); ?></label>
                                       
                                        <input type="text" name="timestamp" id="input-password"
                                            class="form-control form-control-alternative<?php echo e($errors->has('timestamp') ? ' is-invalid' : ''); ?>"
                                            placeholder="<?php echo e(__('2019-06-19 10:14:27')); ?>" value="<?php echo e($timer->timestamp); ?>"  required>

                                        <?php if($errors->has('timestamp')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('timestamp')); ?></strong>
                                        </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-4">
                                    <div class="input-group mb-2">
                                        <div class="custom-file">
                                            <input required type="file" name="poster_image" class="custom-file-input"
                                                id="inputGroupFile02">
                                            <label class="custom-file-label" for="inputGroupFile02">Choose Timer
                                                Background
                                            </label>
                                        </div>

                                    </div>
                                </div>
                               
                            </div>
<div class="row">

        <div class="col-sm-6">
                <label class="form-control-label" for="input-email"><?php echo e(__('Current Image')); ?></label>       
                <div class="input-group-prepend">
                    <img src="<?php echo e(URL::asset("assets/$timer->poster_image")); ?>" class="img-thumbnail" alt="technalatus" width="304" height="236">
                      </div>
                </div>
</div>
                            <div class="text-center">
                                <button type="submit" class="btn btn-success mt-4"><?php echo e(__('Save')); ?></button>
                            </div>

                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    
    <span class="clearfix"></span>


    <?php echo $__env->make('layouts.footers.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['title' => __('Offer Box')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alshoja/ShoppingCart/resources/views/web-settings/Hometimer/hometimer.blade.php ENDPATH**/ ?>