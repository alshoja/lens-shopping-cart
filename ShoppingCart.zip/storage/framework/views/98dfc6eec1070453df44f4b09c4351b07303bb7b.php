<?php $__env->startSection('content'); ?>
<?php echo $__env->make('users.partials.header', ['title' => __('Offer')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container-fluid mt--7">
    <div class="row">
        <div class="col-xl-12 order-xl-1">
            <div class="card bg-secondary shadow">
                <div class="card-header bg-white border-0">
                    <div class="row align-items-center">
                        <div class="col-8">
                            <h3 class="mb-0"><?php echo e(__('Update OfferBox')); ?></h3>
                        </div>
                        <div class="col-4 text-right">
                            <a href="<?php echo e(URL::previous()); ?>"
                                class="btn btn-sm btn-primary"><?php echo e(__('Back to list')); ?></a>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <form method="post" action="<?php echo e(url('update/offerbox',$offer->id)); ?>" autocomplete="off">
                        <?php echo csrf_field(); ?>
<?php echo method_field('put'); ?>
                        <h6 class="heading-small text-muted mb-4"><?php echo e(__('Update Offerbox')); ?></h6>
                        <div class="pl-lg-4">
                            <div class="row">
                                <div class="col-sm">
                                    <div class="form-group<?php echo e($errors->has('title') ? ' has-danger' : ''); ?>">
                                        <label class="form-control-label" for="input-password"><?php echo e(__('Title')); ?></label>
                                       
                                        <input type="text" name="title" id="input-password"
                                            class="form-control form-control-alternative<?php echo e($errors->has('title') ? ' is-invalid' : ''); ?>"
                                            placeholder="<?php echo e(__('Title')); ?>" value="<?php echo e($offer->title); ?>" required>

                                        <?php if($errors->has('title')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('title')); ?></strong>
                                        </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="col-sm">
                                    <div class="form-group<?php echo e($errors->has('textbox_label') ? ' has-danger' : ''); ?>">
                                        <label class="form-control-label" for="input-name"><?php echo e(__('Text box label')); ?></label>
                                       
                                        <input type="text" name="textbox_label" id="input-title"
                                            class="form-control form-control-alternative<?php echo e($errors->has('textbox_label') ? ' is-invalid' : ''); ?>"
                                            placeholder="<?php echo e(__('TextBox Label')); ?>" value="<?php echo e($offer->textbox_label); ?>"
                                            required autofocus>

                                        <?php if($errors->has('textbox_label')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('textbox_label')); ?></strong>
                                        </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="col-sm">
                                    <div class="form-group<?php echo e($errors->has('button_value') ? ' has-danger' : ''); ?>">
                                        <label class="form-control-label" for="input-name"><?php echo e(__('Button Value')); ?></label>
                                       
                                        <input type="text" name="button_value" id="input-title"
                                            class="form-control form-control-alternative<?php echo e($errors->has('button_value') ? ' is-invalid' : ''); ?>"
                                            placeholder="<?php echo e(__('Button Value')); ?>" value="<?php echo e($offer->button_value); ?>"
                                            required autofocus>

                                        <?php if($errors->has('button_value')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('button_value')); ?></strong>
                                        </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                
                            </div>

                            <div class="row">
                                    <div class="col-sm">
                                            <div class="form-group<?php echo e($errors->has('href_url') ? ' has-danger' : ''); ?>">
                                                <label class="form-control-label" for="input-name"><?php echo e(__('Skip Link')); ?></label>
                                               
                                                <input type="url" name="href_url" id="input-title"
                                                    class="form-control form-control-alternative<?php echo e($errors->has('href_url') ? ' is-invalid' : ''); ?>"
                                                    placeholder="<?php echo e(__('Link to skip item-> http://www.example.com/')); ?>" value="<?php echo e($offer->href_url); ?>"
                                                    required autofocus>
        
                                                <?php if($errors->has('href_url')): ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($errors->first('href_url')); ?></strong>
                                                </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                <div class="col-sm">
                                    <div class="form-group<?php echo e($errors->has('href_tittle') ? ' has-danger' : ''); ?>">
                                        <label class="form-control-label" for="input-name"><?php echo e(__('Skip title')); ?></label>
                                       
                                        <input type="text" name="href_tittle" id="input-title"
                                            class="form-control form-control-alternative<?php echo e($errors->has('href_tittle') ? ' is-invalid' : ''); ?>"
                                            placeholder="<?php echo e(__('Skip title')); ?>" value="<?php echo e($offer->href_tittle); ?>"
                                            required autofocus>

                                        <?php if($errors->has('href_tittle')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('href_tittle')); ?></strong>
                                        </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                               
                            </div>
                            <div class="row">
                                    <div class="col-sm-6 mt-sm-4 mb-sm-5">
                                    <div class="form-group<?php echo e($errors->has('description') ? ' has-danger' : ''); ?>">
                                            <label class="form-control-label" for="input-email"><?php echo e(__('Description')); ?></label>
                                            <textarea name="description"
                                                class="form-control form-control-alternative<?php echo e($errors->has('description') ? ' is-invalid' : ''); ?>"
                                                id="exampleFormControlTextarea1" value="<?php echo e(old('description')); ?>" rows="3"
                                                placeholder="<?php echo e(__('A brief description about your Offer :)')); ?>"><?php echo e($offer->description); ?></textarea>
                                            <?php if($errors->has('description')): ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($errors->first('description')); ?></strong>
                                            </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                           </div>
                                <div class="row">
                                <div class="col-sm">
                                        <label class="form-control-label" for="input-password"><?php echo e(__('Show on load')); ?></label>
                                        <div class="input-group mb-2">
                                                <span class="clearfix"></span>
                                                <label class="custom-toggle">
                                                    <?php if($offer->isActive == 1): ?>
                                                    <input name="isActive" value="1" type="checkbox" checked>  
                                                    <?php else: ?>
                                                    <input name="isActive" value="1"  type="checkbox" >  
                                                    <?php endif; ?>
                                                  
                                                    <span class="custom-toggle-slider rounded-circle"></span>
                                                </label>
    
                                        </div>
                                    </div>  
                                    
                            </div>

                          

                            
                            <div class="text-center">
                                <button type="submit" class="btn btn-success mt-4"><?php echo e(__('Save')); ?></button>
                            </div>

                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    
    <span class="clearfix"></span>
 

    <?php echo $__env->make('layouts.footers.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['title' => __('Offer Box')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alshoja/ShoppingCart/resources/views/web-settings/offerbox/offer.blade.php ENDPATH**/ ?>