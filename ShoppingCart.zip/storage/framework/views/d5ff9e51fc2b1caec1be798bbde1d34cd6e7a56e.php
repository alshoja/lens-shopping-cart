<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('sidebar'); ?>
##parent-placeholder-19bd1503d9bad449304cc6b4e977b74bac6cc771##


<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- banner -->
<div class="banner">
    <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
        <ol class="carousel-indicators">
            <?php echo e($counter = 0); ?>

            <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
            <?php $__currentLoopData = $slider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sliderdata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li data-target="#carouselExampleIndicators" data-slide-to="<?php echo e($counter++); ?>"></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ol>
        <div class="carousel-inner" role="listbox">
            <?php $s = 0 ?>
            <?php $__currentLoopData = $slider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sliderdata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($sliderdata->isActive === 1): ?>
            <div class="carousel-item active" style="
			background: -webkit-linear-gradient(rgba(23, 22, 23, 0.2), rgba(23, 22, 23, 0.5)), url(<?php echo e(URL::asset("assets/$sliderdata->image")); ?>) no-repeat;
			background: -moz-linear-gradient(rgba(23, 22, 23, 0.2), rgba(23, 22, 23, 0.5)), url(<?php echo e(URL::asset("assets/$sliderdata->image")); ?>) no-repeat;
			background: -ms-linear-gradient(rgba(23, 22, 23, 0.2), rgba(23, 22, 23, 0.5)), url(<?php echo e(URL::asset("assets/$sliderdata->image")); ?>) no-repeat;
			background: linear-gradient(rgba(23, 22, 23, 0.2), rgba(23, 22, 23, 0.5)), url(<?php echo e(URL::asset("assets/$sliderdata->image")); ?>) no-repeat;
			background-size: cover;
					">
                <?php else: ?>
                <div class="carousel-item" style="
	background: -webkit-linear-gradient(rgba(23, 22, 23, 0.2), rgba(23, 22, 23, 0.5)), url(<?php echo e(URL::asset("assets/$sliderdata->image")); ?>) no-repeat;
    background: -moz-linear-gradient(rgba(23, 22, 23, 0.2), rgba(23, 22, 23, 0.5)), url(<?php echo e(URL::asset("assets/$sliderdata->image")); ?>) no-repeat;
    background: -ms-linear-gradient(rgba(23, 22, 23, 0.2), rgba(23, 22, 23, 0.5)), url(<?php echo e(URL::asset("assets/$sliderdata->image")); ?>) no-repeat;
    background: linear-gradient(rgba(23, 22, 23, 0.2), rgba(23, 22, 23, 0.5)), url(<?php echo e(URL::asset("assets/$sliderdata->image")); ?>) no-repeat;
    background-size: cover;
			">
                    <?php endif; ?>
                    <div class="carousel-caption text-center">
                        <h3><?php echo e($sliderdata->main_heading); ?>

                            <span><?php echo e($sliderdata->sub_heading); ?></span>
                        </h3>
                        <a href="<?php echo e(url('product/shop')); ?>"
                            class="btn btn-sm animated-button gibson-three mt-4"><?php echo e($sliderdata->button_value); ?></a>

                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="sr-only">Previous</span>
            </a>
            <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="sr-only">Next</span>
            </a>
        </div>
        <!--//banner -->
    </div>
</div>
<!--//banner-sec-->
<section class="banner-bottom-wthreelayouts py-lg-5 py-3">
    <div class="container-fluid">
        <div class="inner-sec-shop px-lg-4 px-3">
            <h3 class="tittle-w3layouts my-lg-4 my-4">New Arrivals for you </h3>
            <div class="row">
                <!-- /womens -->

                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-3 product-men women_two">
                    <div class="product-googles-info googles">
                        <div class="men-pro-item">
                            <div class="men-thumb-item">
                                <?php $__currentLoopData = $item->productImage; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                
                                <img src=<?php echo e(URL::asset("assets/$img->image")); ?> class="img-fluid" alt="">
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <div class="men-cart-pro">
                                    <div class="inner-men-cart-pro">
                                        <a href="<?php echo e(url('product/item',$item->id)); ?>" class="link-product-add-cart">Quick
                                            View</a>
                                    </div>
                                </div>
                                <span class="product-new-top">New</span>
                            </div>
                            <div class="item-info-product">

                                <div class="info-product-price">
                                    <div class="grid_meta">
                                        <div class="product_price">
                                            <h4>
                                                <a href="single.html"><?php echo e($item->name); ?></a>
                                            </h4>
                                            <div class="grid-price mt-2">
                                                <span class="money "> ₹ <?php echo e($item->amount); ?></span>
                                            </div>
                                        </div>
                                        <ul class="stars">
                                            <?php for($i = 0; $i < $item->star; $i++): ?>
                                            <li>
                                            <a>
                                                    <i class="fa fa-star" style="color: orangered" aria-hidden="true"></i>
                                            </a>
                                            </li>
                                            <?php endfor; ?>
                                            <?php for($i = 0; $i < 5-$item->star; $i++): ?>
                                            <li>
                                            <a>
                                                    <i class="fa fa-star"  aria-hidden="true"></i>
                                            </a>
                                            </li>
                                            <?php endfor; ?>
                                        </ul>
                                    </div>
                                    <div class="googles single-item hvr-outline-out">
                                        <form action="#" method="post">
                                            <input type="hidden" name="cmd" value="_cart">
                                            <input type="hidden" name="add" value="1">
                                            <input type="hidden" name="googles_item" value="<?php echo e($item->name); ?>">
                                            <input type="hidden" name="amount" value="<?php echo e($item->amount); ?>">
                                            <input type="hidden" name="item_id" value=" <?php echo e($item->id); ?>">
                                            <button type="submit" class="googles-cart pgoogles-cart">
                                                <i class="fas fa-cart-plus"></i>
                                            </button>


                                        </form>

                                    </div>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                        </div>
                    </div>
                </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <!-- //womens -->

            
    </div>
    <!--//row-->
    <!--/meddle-- banner-mid.jpg-->
    <div class="row">
        <div class="col-md-12 middle-slider my-4"
            style=" background: url(<?php echo e(URL::asset("assets/$middle->poster_image")); ?>) no-repeat 0px 0px;">
            <div class="middle-text-info ">

                <h3 class="tittle-w3layouts two text-center my-lg-4 mt-3"><?php echo e($middle->title); ?></h3>
                <div class="simply-countdown-custom" id="simply-countdown-custom"></div>

            </div>
        </div>
    </div>
    <!--//meddle-->
    <!--/slide-->
    <div class="slider-img mid-sec">
        <!--//banner-sec-->
        <div class="mid-slider">
            <div class="owl-carousel owl-theme row">
                <?php $__currentLoopData = $product_slider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item_slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="item">
                    <div class="gd-box-info text-center">
                        <div class="product-men women_two bot-gd">
                            <div class="product-googles-info slide-img googles">
                                <div class="men-pro-item">
                                    <div class="men-thumb-item">
                                        <?php $__currentLoopData = $item_slider->productImage; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        
                                        <img src="<?php echo e(URL::asset("assets/$item->image")); ?>" class="img-fluid"
                                            alt="">
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <div class="men-cart-pro">
                                            <div class="inner-men-cart-pro">
                                                    <a href="<?php echo e(url('product/item',$item->id)); ?>" class="link-product-add-cart">
                                               Quick View</a>
                                            </div>
                                        </div>
                                        <span class="product-new-top">New one</span>
                                    </div>
                                    <div class="item-info-product">

                                        <div class="info-product-price">
                                            <div class="grid_meta">
                                                <div class="product_price">
                                                    <h4>
                                                        <a
                                                            href=<?php echo e(url('product/item',$item_slider->id)); ?>><?php echo e($item_slider->name); ?></a>
                                                    </h4>
                                                    <div class="grid-price mt-2">
                                                        <span class="money ">$ <?php echo e($item_slider->amount); ?></span>
                                                    </div>
                                                </div>
                                                <ul class="stars">
                                                    <?php for($i = 0; $i < $item_slider->star; $i++): ?>
                                                    <li>
                                                    <a>
                                                            <i class="fa fa-star" style="color: orangered" aria-hidden="true"></i>
                                                    </a>
                                                    </li>
                                                    <?php endfor; ?>
                                                    <?php for($i = 0; $i < 5-$item_slider->star; $i++): ?>
                                                    <li>
                                                    <a>
                                                            <i class="fa fa-star"  aria-hidden="true"></i>
                                                    </a>
                                                    </li>
                                                    <?php endfor; ?>
                                                </ul>
                                            </div>
                                            <div class="googles single-item hvr-outline-out">
                                                <form action="#" method="post">
                                                    <input type="hidden" name="cmd" value="_cart">
                                                    <input type="hidden" name="add" value="1">
                                                    <input type="hidden" name="googles_item" value=" <?php echo e($item_slider->name); ?>">
                                                    <input type="hidden" name="amount" value=" <?php echo e($item_slider->amount); ?>">
                                                    <input type="hidden" name="item_id" value=" <?php echo e($item_slider->id); ?>">
                                                    <button type="submit" class="googles-cart pgoogles-cart">
                                                        <i class="fas fa-cart-plus"></i>
                                                    </button>
                                                </form>

                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>
    </div>
    <!-- /testimonials -->
    <div class="testimonials py-lg-4 py-3 mt-4">
        <div class="testimonials-inner py-lg-4 py-3">
            <h3 class="tittle-w3layouts text-center my-lg-4 my-4">Tesimonials</h3>
            <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
                <div class="carousel-inner" role="listbox">
                    
                    <?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $person): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <?php if($person->is_active): ?>
                    <div class="carousel-item active">
                        <?php else: ?>
                        <div class="carousel-item">
                            <?php endif; ?>
                            <div class="testimonials_grid text-center">
                                <h3><?php echo e($person->work); ?>

                                    <span><?php echo e($person->customer_name); ?></span>
                                </h3>
                                <label><?php echo e($person->country); ?></label>
                                <p><?php echo e(str_limit($person->description, $limit = 100, $end = '...')); ?></p>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <a class="carousel-control-prev test" href="#carouselExampleControls" role="button"
                            data-slide="prev">
                            <span class="fas fa-long-arrow-alt-left"></span>
                            <span class="sr-only">Previous</span>
                        </a>
                        <a class="carousel-control-next test" href="#carouselExampleControls" role="button"
                            data-slide="next">
                            <span class="fas fa-long-arrow-alt-right" aria-hidden="true"></span>
                            <span class="sr-only">Next</span>

                        </a>
                    </div>
                </div>
            </div>
        </div>
        <!-- //testimonials -->
        <div class="row galsses-grids pt-lg-5 pt-3">
            <?php $__currentLoopData = $editorsPic; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Epic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-6 galsses-grid-left">
                <figure class="effect-lexi">
                    <img src=<?php echo e(URL::asset("assets/$Epic->image")); ?> alt="" class="img-fluid">
                    <figcaption>
                        <h3>
                            <span><?php echo e($Epic->heading); ?></span>
                        </h3>
                        <p> <?php echo e(str_limit($Epic->hover_data, $limit = 10, $end = '...')); ?></p>

                    </figcaption>
                </figure>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <!-- /grids -->
        <div class="bottom-sub-grid-content py-lg-5 py-3">
            <div class="row">
                <?php $__currentLoopData = $first_feature; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                <div class="col-lg-4 bottom-sub-grid text-center">
                    
                    <div class="bt-icon">
                            <?php echo $f1->icon; ?>

                        </div>
                    <h4 class="sub-tittle-w3layouts my-lg-4 my-3"><?php echo e($f1->heading); ?></h4>
                    <p><?php echo e(str_limit($f1->description , $limit = 150, $end = '...')); ?></p>
                    <p>
                        <a href="shop.html"
                            class="btn btn-sm animated-button gibson-three mt-4"><?php echo e($f1->button_value); ?></a>
                    </p>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <!-- /.col-lg-4 -->
            </div>
        </div>
        <!-- //grids -->
        <!-- /clients-sec -->
        <div class="testimonials p-lg-5 p-3 mt-4">
            <div class="row last-section">
                <?php $__currentLoopData = $second_feature; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-3 footer-top-w3layouts-grid-sec">
                    <div class="mail-grid-icon text-center">
                        <?php echo $f2->icon; ?>

                    </div>
                    <div class="mail-grid-text-info">
                        <h3><?php echo e($f2->heading); ?></h3>
                        <p><?php echo e(str_limit($f2->description , $limit = 94, $end = '...')); ?></p>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <!-- //clients-sec -->
    </div>
    </div>
</section>
<!-- about -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/educ/OwnProjects/ShoppingCart/resources/views/welcome.blade.php ENDPATH**/ ?>